# main_astrolabe.py
# $Id$

import os

os.system("rm -Rf astrolabe_parts astrolabes ProcessedData")
os.system("rm -Rf doc/*.aux doc/*.dvi doc/*.log doc/*.pdf doc/*.ps doc/tmp")

os.system("python YBSC_process.py")
os.system("pyxplot astrolabe.ppl")
os.system("rm -Rf astrolabe_parts/*.eps astrolabe_parts/mother_front_combi* doc/*.aux doc/*.log doc/*.pdf doc/tmp ProcessedData")

os.system("rm -Rf   ../../auto/tmp/html/astrolabe")
os.system("mkdir -p ../../auto/tmp/html/astrolabe")

os.system("rm -Rf doc/*.aux doc/*.dvi doc/*.log doc/*.pdf doc/*.ps doc/tmp doc/*.out")
os.system("rm -Rf astrolabe_parts/*.eps")

os.system("cd .. ; cp -r astrolabe /tmp ; cd /tmp ; rm -Rf /tmp/astrolabe/.svn /tmp/astrolabe/*/.svn ; zip -r astrolabe.zip astrolabe")
os.system("mv /tmp/astrolabe.zip ../../auto/tmp/html/astrolabe")

os.system("cp astrolabes/astrolabe_52N.pdf ../../auto/tmp/html/astrolabe/astrolabe.pdf")
os.system("mv astrolabes ../../auto/tmp/html/astrolabe/pdfs")

os.system("rm -Rf astrolabe_parts astrolabes ProcessedData")
