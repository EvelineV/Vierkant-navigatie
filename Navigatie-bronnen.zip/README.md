# Vierkant-navigatie
Navigatie kampprogramma bestemd voor Vierkant voor Wiskunde kamp B - 2018

## Nodig:
- werkblad horloge: aantal deelnemers / 3, gewoon papier
- `astrolabe_52N_karton.pdf`, op stevig papier.
- `astrolabe_52N_plastic.pdf`, op transparant (overhead projector sheets?), zoveel als er deelnemers zijn.
- 1 splitpen voor iedere deelnemer
- Gaatjestang: om gat voor de splitpen in het plastic te maken
- (optioneel) Een of meerdere wereldbollen/globes ter illustratie van sommige onderwerpen in hoofdstuk 2.
- touw, stukken van 1-2 meter lang, ~1 per deelnemer (bij bouwmarkt te vinden voor <€10, knippen op zondagavond).

## PDFs en releases:
Track PDF bestanden voor novemberdeadline, januarivergadering, voorbereidingsweekend, regiovergaderingen en definitieve versie op een aparte branch. Deze PDFs kunnen ook gepubliceerd worden op de Vierkant wiki. Markeer de TeX sources voor iedere PDF release met een tag op de master branch.

## To do:
- Outline
- Practica
- Schrijfwerk
-
